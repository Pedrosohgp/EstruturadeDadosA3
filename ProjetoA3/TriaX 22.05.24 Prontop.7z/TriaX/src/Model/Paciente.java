package Model;

public class Paciente {

    private String nome;
    private int idade;
    private String sexo;
    private Prioridades prioridade;
    private Especialidades especialidade;
    private boolean statusAtendido;

    public enum Prioridades {
        VERMELHO, LARANJA, AMARELO, VERDE, AZUL
    }

    public enum Especialidades {
        CARDIOLOGISTA,
        DERMATOLOGISTA,
        ENDOCRINOLOGISTA,
        GASTROENTEROLOGISTA,
        GINECOLOGISTA,
        INFECTOLOGISTA,
        NEFROLOGISTA,
        NEUROLOGISTA,
        OFTALMOLOGISTA,
        ORTOPEDISTA,
        OTORRINOLARINGOLOGISTA,
        PNEUMOLOGISTA,
        PSIQUIATRA,
        REUMATOLOGISTA,
        UROLOGISTA
    }

    public Paciente(String nome, int idade, String sexo, Prioridades prioridade, Especialidades especialidade, boolean statusAtendido) {
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
        this.prioridade = prioridade;
        this.especialidade = especialidade;
        this.statusAtendido = statusAtendido;
    }

    public Paciente(Paciente objeto) {
        this.nome = objeto.getNome();
        this.idade = objeto.getIdade();
        this.sexo = objeto.getSexo();
        this.prioridade = objeto.getPrioridade();
        this.especialidade = objeto.getEspecialidade();
        this.statusAtendido = objeto.isStatusAtendido();
    }

    // Getters e setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public Prioridades getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(Prioridades prioridade) {
        this.prioridade = prioridade;
    }

    public boolean isStatusAtendido() {
        return statusAtendido;
    }

    public void setStatusAtendido(boolean statusAtendido) {
        this.statusAtendido = statusAtendido;
    }
    
    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Especialidades getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(Especialidades especialidade) {
        this.especialidade = especialidade;
    }
    
    @Override
    public String toString() {
        return "\n Nome: " + this.getNome()
                + "\n Idade: " + this.getIdade()
                + "\n Prioridade: " + this.getPrioridade()
                + "\n -----------";
    }
}