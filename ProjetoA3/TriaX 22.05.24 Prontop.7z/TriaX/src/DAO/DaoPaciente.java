
package DAO;

import Model.Paciente;
import java.util.Arrays;

public class DaoPaciente {
    private static DaoPaciente instancia;
    private Paciente[] pacientes;
    private int size;
    private Paciente[] atendidos;
    private int atendidosSize = 0;
    private Paciente emAtendimento;
    
    public DaoPaciente() {
        this.pacientes = new Paciente[10];  // Tamanho inicial do array
        this.atendidos = new Paciente[10];
        this.size = 0;
    }
    
    public static DaoPaciente getInstance(){ //Singleton
        if(instancia == null){
            instancia = new DaoPaciente();
        }
        return instancia;
    }
    
    public boolean adicionarPaciente(Paciente paciente) {
        if (size == pacientes.length) {
            pacientes = Arrays.copyOf(pacientes, pacientes.length * 2);
        }
        int i;
        for (i = size - 1; i >= 0; i--) {
            if (pacientes[i].getPrioridade().ordinal() > paciente.getPrioridade().ordinal()) {
                pacientes[i + 1] = pacientes[i];
            } else {
                break;
            }
        }
        pacientes[i + 1] = paciente;
        size++;
        return true;
    }
    
    public Paciente emAtendimento(){
        return emAtendimento;
    }
    
    public void setEmAtendimento(Paciente paciente){
        emAtendimento = paciente;
    }
      
    public boolean pacienteAtendido(Paciente emAtendimento){
        if(emAtendimento != null){
            atendidos[atendidosSize] = emAtendimento;
            atendidosSize++;
            return true;
        }
        return false;
    }

    /*public Paciente proximoPaciente() {
        if (size == 0) {
            return null;
        }
        Paciente proximo = pacientes[0];
        emAtendimento = proximo;
        System.arraycopy(pacientes, 1, pacientes, 0, size - 1);
        size--;
        return proximo;
    }*/

    
    /*public Paciente clearEmAtendimento(){
        emAtendimento = null;
        return emAtendimento;
    }*/

    
    /*public int getPacienteSize(){
        return size;
    }*/
    
    public boolean deletarPaciente(String nome){
        boolean flag = false;
        int index = 0;
        int indexCopyPacientes = 0;
        Paciente[] copyPacientes = new Paciente[pacientes.length];
        for (Paciente paciente : pacientes){
            if(paciente != null){
                if(paciente.getNome().equals(nome)){
                    flag = true;
                    index++;
                    continue;
                }
                copyPacientes[indexCopyPacientes] = pacientes[index];
                indexCopyPacientes++;
                index++;
            }
        }
        size--;
        for(int i = 0; i < copyPacientes.length; i++){
            pacientes[i] = copyPacientes[i];
        }
        return flag;
    }

    public Paciente[] getPacientes() {
        return Arrays.copyOf(pacientes, size);
    }
    
    public Paciente[] getAtendidos(){
        return Arrays.copyOf(atendidos, atendidosSize);
    }
}
