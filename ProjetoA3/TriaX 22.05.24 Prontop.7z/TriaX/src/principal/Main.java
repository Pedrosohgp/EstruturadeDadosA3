package principal;

import View.LoginFrame;
import javax.swing.*;
import View.TelaInicial;

public class Main{
    public static void main(String[] args) {
        // Executando a aplicação
        /*SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });*/
        TelaInicial objetoTela = new TelaInicial();
        objetoTela.setVisible(true);
    }
}
