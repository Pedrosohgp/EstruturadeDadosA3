package View;

import javax.swing.*;

public class LoginFrame extends JFrame {

    private String login = "adm";
    private String senha = "1234";

    public LoginFrame() {
        // Configuração do JFrame
        setTitle("Sistema de Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Criando os componentes
        JLabel loginLabel = new JLabel("Login:");
        JTextField loginField = new JTextField(15);
        JLabel senhaLabel = new JLabel("Senha:");
        JPasswordField senhaField = new JPasswordField(15);
        JButton loginButton = new JButton("Entrar");
        JLabel messageLabel = new JLabel();

        // Configurando o layout
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(loginLabel);
        panel.add(loginField);
        panel.add(senhaLabel);
        panel.add(senhaField);
        panel.add(loginButton);
        panel.add(messageLabel);
        
        add(panel);

        // Configurando a ação do botão de login
        loginButton.addActionListener(e -> {
            String checkLogin = loginField.getText();
            String checkSenha = new String(senhaField.getPassword());

            if (login.equals(checkLogin) && senha.equals(checkSenha)) {
                messageLabel.setText("Logado!");

                // Abrir TelaPrincipal_1
                TelaInicial telaInicial = new TelaInicial();
                telaInicial.setVisible(true);
                
                // Fechar o frame de login (opcional)
                dispose();
            } else {
                messageLabel.setText("Login/senha incorretos.");
            }
        });
    }
}